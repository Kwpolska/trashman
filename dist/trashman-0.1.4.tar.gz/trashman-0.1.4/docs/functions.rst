==================================================================
Functions (for people planning to depend on Trashman as a library)
==================================================================
:Author: Kwpolska
:Copyright: See Appendix B.
:Date: 2012-08-10
:Version: 0.1.4

This is an auto-generated documentation of the Trashman suite.  It is
bare-bones, and you’d be better off reading the source code yourself.

.. automodule:: trashman
   :members:
