This directory contains shell completions.  Currently, only a zsh completion is ready.
