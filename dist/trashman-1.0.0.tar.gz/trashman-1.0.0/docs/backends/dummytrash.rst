==========
DummyTrash
==========
:Name: DummyTrash
:Module: dummytrash
:Author: Kwpolska
:Specification: n/a
:OS: any
:Description: A dummy backend, printing all the requests it gets.
:Copyright: See Appendix A.
:Date: 2012-08-25
:Version: 0.2.4

.. index:: DummyTrash

.. automodule:: trashman.backends.dummytrash
   :members:
