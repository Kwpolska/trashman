=================================
Global Functions and Modules List
=================================
:Author: Kwpolska
:Copyright: See Appendix A.
:Date: 2012-08-27
:Version: 1.0.0

.. index:: global functions

This is an auto-generated documentation of the Trashman suite.  It is
bare-bones, and you’d be better off reading the source code yourself.

__init__.py
===========
.. automodule:: trashman.__init__
   :members:

tmds.py (TMDS — Trashman Data Storage)
======================================
.. automodule:: trashman.tmds
   :members:

main.py (main())
================
.. automodule:: trashman.main
   :members:
