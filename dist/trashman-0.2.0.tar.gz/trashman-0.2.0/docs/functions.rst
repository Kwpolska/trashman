==============
Functions List
==============
:Author: Kwpolska
:Copyright: See Appendix A.
:Date: 2012-08-13
:Version: 0.2.0

.. index:: functions

This is an auto-generated documentation of the Trashman suite.  It is
bare-bones, and you’d be better off reading the source code yourself.

.. automodule:: trashman
   :members:
